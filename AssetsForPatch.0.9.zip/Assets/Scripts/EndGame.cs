﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EndGame : MonoBehaviour {

    private PauseGame pauseGame;

	void Start ()
    {
        pauseGame = GetComponent<PauseGame>();
	}

    // Open EndGamePanel and disable use of pause menu
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.GetComponent<Collider2D>().tag == "Player")
        {
            pauseGame.canUsePauseMenu = false;
            pauseGame.endGamePanel.gameObject.SetActive(true);
            Time.timeScale = 0;
            Debug.Log("Game finnished");
        }
    }
}
