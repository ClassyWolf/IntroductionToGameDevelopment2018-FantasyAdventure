Added a few test with multiple doors for potential hazzards with triggers

fixed certain audio problems so multiple effects like walking plays only once, not
prefect since it silences other effects, needs research to make propperly

added a background track to check that it is working, not final

Added a few puzzle prefabs and added them into the test room

Script folder:
Cleaned up and Hook script added

Prefab folder:
Cleaned and updated the player character

When opened you need to check that cinemachine is added to the project.
Check that all layers are correct:
	8: Ground
	9: Hazzard
	10: Player
	11: Rope
	12: Pivot

After that is set up everything should work as intended.