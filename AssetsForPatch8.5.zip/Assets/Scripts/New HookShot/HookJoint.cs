﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class HookJoint : MonoBehaviour {

    //public values
    public float distance = 10f;
    public float drag = 1;
    public int hookAmount = 3;
    public LayerMask pivot;
    public DistanceJoint2D joint;
    public bool attached = false;
    public LineRenderer rope;
    public Rigidbody2D player;

    //required scripts
    public RopeLength ropeLength;
    public PlayerStatus playerStatus;

    //private values
    private Vector3 targetPos;
    private RaycastHit2D hit;
    [SerializeField] private Text hookText;

    // Use this for initialization
    void Start () {
        joint = GetComponent<DistanceJoint2D>();
        joint.enabled = false;
        rope.enabled = false;
	}

    // Update is called once per frame
    void FixedUpdate() {
        if(hookAmount > 0) { 
            if (Input.GetMouseButtonDown(0))
            {
                targetPos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
                targetPos.z = 0;

                hit = Physics2D.Raycast(transform.position, targetPos - transform.position, distance, pivot);

                if (hit.collider != null)
                {
                    joint.enabled = true;
                    joint.connectedBody = hit.collider.gameObject.GetComponent<Rigidbody2D>();
                    joint.connectedAnchor = hit.point - new Vector2(hit.collider.transform.position.x, hit.collider.transform.position.y);
                    joint.distance = 2.5f;
                    attached = true;
                    player.drag = drag;
                    rope.enabled = true;
                    rope.SetPosition(0, transform.position);
                    rope.SetPosition(1, hit.point);
                    hookAmount -= 1;
                }
            }

            if (attached == true)
            {
                rope.SetPosition(0, transform.position);
            }

            if(Input.GetMouseButtonDown(1))
            {
                joint.enabled = false;
                rope.enabled = false;
                attached = false;
                player.drag = 20;
            }
        }

        if(playerStatus.isGrounded == true)
        {
            hookAmount = 3;
        }

        ropeLength.HandleRopeLength();
        hookText.text = "Hooks: " + hookAmount.ToString();
    }
}
