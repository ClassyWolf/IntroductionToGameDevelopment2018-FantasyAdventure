Script folder:
Cleaned up and Hook script added

Prefab folder:
Cleaned and updated the player character

When opened you need to check that cinemachine is added to the project.
Check that all layers are correct:
	8: Ground
	9: Hazzard
	10: Player
	11: Rope
	12: Pivot

After that is set up everything should work as intended.