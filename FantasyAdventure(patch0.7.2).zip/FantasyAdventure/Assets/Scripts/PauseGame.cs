﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PauseGame : MonoBehaviour
{

    public Transform panel;


    // Open given panel and stop gametime or close panel and start gametime again when pressed esc
    public void Update()
    {
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            if (panel.gameObject.activeInHierarchy == false)
            {
                panel.gameObject.SetActive(true);
                Time.timeScale = 0;
            }
            else
            {
                panel.gameObject.SetActive(false);
                Time.timeScale = 1;
            }
        }
    }

    public void UnPauseGame()
    {
        panel.gameObject.SetActive(false);
        Time.timeScale = 1;
    }

}
