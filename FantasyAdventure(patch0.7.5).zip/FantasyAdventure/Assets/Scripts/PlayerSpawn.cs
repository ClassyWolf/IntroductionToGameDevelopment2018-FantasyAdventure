﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerSpawn : MonoBehaviour {

    [SerializeField] CharacterStatus characterStatus;
    [SerializeField] Rigidbody2D playerCharacter;
    [SerializeField] Transform spawn;

    public void respawn()
    {
        playerCharacter.transform.position = spawn.position;
    }
}
