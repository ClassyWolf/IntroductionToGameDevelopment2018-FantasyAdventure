﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerInput : MonoBehaviour
{

    private PlayerMovement playerMovement;
    private PlayerManager playerManager;

    private void Start()
    {
        playerManager = GetComponent<PlayerManager>();
        playerMovement = GetComponent<PlayerMovement>();
    }

    // Utilize player movements
    private void FixedUpdate()
    {
        playerMovement.PlayerMove();
        playerMovement.Jumping();
    }

}
