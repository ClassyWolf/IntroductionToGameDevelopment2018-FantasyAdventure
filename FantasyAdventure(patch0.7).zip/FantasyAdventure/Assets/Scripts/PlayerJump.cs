﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerJump : MonoBehaviour {

    /*private Rigidbody2D rb2D;
    public float speedForce;


    public void Awake()
    {
        rb2D = gameObject.AddComponent<Rigidbody2D>();
    }

	void Update ()
    {
		
	}

    public void Jump()
    {
        if (Input.GetKeyDown(KeyCode.Space))
        {
            rb2D.AddForce(transform.up.impulse * speedForce);

        }
    }*/
}
